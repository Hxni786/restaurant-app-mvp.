// App.js — FULL WORKING VERSION with Mock Face ID (Works in Expo Go)

import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Image,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from "react-native";

// ---- LOGOS ----
const mainLogo = "https://i.postimg.cc/Zq22gqyW/logo.png";
const tableIcon = "https://cdn-icons-png.flaticon.com/512/149/149508.png";
const easypaisaLogo = "https://i.postimg.cc/tg8rRvc6/Easypaisa-logo.png";
const jazzCashLogo = "https://i.postimg.cc/Mp96LVFs/new-Jazzcash-logo.png";
const scanIcon = "https://cdn-icons-png.flaticon.com/512/481/481195.png";
const managerIcon = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
const customerIcon = "https://cdn-icons-png.flaticon.com/512/3135/3135789.png";
const menuIcon = "https://cdn-icons-png.flaticon.com/512/1046/1046784.png";
const orderIcon = "https://cdn-icons-png.flaticon.com/512/263/263142.png";
const reserveIcon = "https://cdn-icons-png.flaticon.com/512/3105/3105833.png";
const myReservationIcon = "https://cdn-icons-png.flaticon.com/512/2088/2088617.png";
const faceIdIcon = "https://cdn-icons-png.flaticon.com/512/3197/3197919.png";

// ---- MENU DATA ----
const menuData = [
  { id: "1", name: "Zinger Burger", price: 500, icon: "https://cdn-icons-png.flaticon.com/512/1046/1046784.png" },
  { id: "2", name: "Pizza", price: 1200, icon: "https://cdn-icons-png.flaticon.com/512/3595/3595455.png" },
  { id: "3", name: "Pasta", price: 900, icon: "https://cdn-icons-png.flaticon.com/512/3075/3075977.png" },
  { id: "4", name: "Cold Drink", price: 150, icon: "https://cdn-icons-png.flaticon.com/512/2738/2738730.png" },
  { id: "5", name: "Chicken Biryani", price: 350, icon: "https://cdn-icons-png.flaticon.com/512/1046/1046751.png" },
  { id: "6", name: "French Fries", price: 200, icon: "https://cdn-icons-png.flaticon.com/512/1046/1046786.png" },
];

export default function App() {
  const [screen, setScreen] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [searchName, setSearchName] = useState("");
  const [userRole, setUserRole] = useState(null);
  const [managerPassword, setManagerPassword] = useState("");

  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);

  const [tables, setTables] = useState([]);
  const [todayTables, setTodayTables] = useState([]);
  const [timeRequired, setTimeRequired] = useState("");

  const [feedbacks, setFeedbacks] = useState([]);
  const [rating, setRating] = useState("");
  const [review, setReview] = useState("");

  const [, forceUpdate] = useState(0);

  const [selectedOrder, setSelectedOrder] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [faceScanning, setFaceScanning] = useState(false); // For Face ID simulation

  // For search results
  const [searchedOrders, setSearchedOrders] = useState([]);
  const [searchedReservations, setSearchedReservations] = useState([]);
  const [orderSearchPerformed, setOrderSearchPerformed] = useState(false);
  const [reservationSearchPerformed, setReservationSearchPerformed] = useState(false);

  // ===== live timer =====
  useEffect(() => {
    const t = setInterval(() => forceUpdate((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // ===== splash timer =====
  useEffect(() => {
    if (screen === "splash") {
      const t = setTimeout(() => setScreen("roleSelect"), 3000);
      return () => clearTimeout(t);
    }
  }, [screen]);

  // ===== scan timer =====
  useEffect(() => {
    if (scanning) {
      const t = setTimeout(() => {
        setScanning(false);
        setScreen("scanResult");
      }, 3000);
      return () => clearTimeout(t);
    }
  }, [scanning]);

  // ===== remove expired tables =====
  useEffect(() => {
    const c = setInterval(() => {
      const now = new Date();
      setTables((p) => p.filter((t) => new Date(t.end) > now));
    }, 5000);
    return () => clearInterval(c);
  }, []);

  // ===== LOGIN =====
  const loginHandler = () => {
    if (!email || !password) return Alert.alert("Error", "Enter email & password");
    setScreen("splash");
  };

  // ===== ROLE SELECTION =====
  const selectRole = (role) => {
    if (role === "manager") {
      setScreen("managerPassword");
    } else {
      setUserRole("customer");
      setScreen("main");
    }
  };

  // ===== MANAGER PASSWORD VERIFICATION =====
  const verifyManager = () => {
    if (managerPassword === "Hassan") {
      setUserRole("manager");
      setManagerPassword("");
      setScreen("main");
    } else {
      Alert.alert("Access Denied", "Incorrect manager password");
      setManagerPassword("");
    }
  };

  // ===== MOCK FACE ID LOGIN (Works in Expo Go) =====
  const mockFaceIdLogin = () => {
    setFaceScanning(true);
    
    // Simulate face scanning animation for 2 seconds
    setTimeout(() => {
      setFaceScanning(false);
      
      // 90% success rate for demo (you can adjust this)
      const success = Math.random() < 0.9;
      
      if (success) {
        Alert.alert(
          "✅ Face ID Success", 
          "Authentication successful! Logging you in...",
          [
            { 
              text: "OK", 
              onPress: () => {
                setManagerPassword("Hassan");
                // Auto verify after successful face ID
                setUserRole("manager");
                setManagerPassword("");
                setScreen("main");
              }
            }
          ]
        );
      } else {
        Alert.alert(
          "❌ Face ID Failed", 
          "Face recognition failed. Please try again or use password."
        );
      }
    }, 2000);
  };

  // ===== ORDER =====
  const addToCart = (item) => setCart((p) => [...p, item]);
  const totalPayment = cart.reduce((s, i) => s + i.price, 0);

  const placeOrder = () => {
    const cleanName = customerName.trim();
    if (!cleanName) return Alert.alert("Error", "Enter customer name");
    if (!cart.length) return Alert.alert("Error", "Cart empty");

    const createNewOrder = () => {
      setOrders((p) => [
        ...p,
        { id: Date.now().toString(), name: cleanName, items: cart, total: totalPayment },
      ]);
      setCart([]);
      setCustomerName("");
      Alert.alert("Success", "Order placed successfully!");
    };

    const existing = orders.find((o) => o.name === cleanName);

    if (existing) {
      Alert.alert("Existing Order", `${cleanName} already has an order.`, [
        {
          text: "Update Previous",
          onPress: () => {
            const updated = [...orders];
            const i = updated.findIndex((o) => o.id === existing.id);
            updated[i].items.push(...cart);
            updated[i].total += totalPayment;
            setOrders(updated);
            setCart([]);
            setCustomerName("");
            Alert.alert("Success", "Order updated successfully!");
          },
        },
        { text: "Create New", onPress: createNewOrder },
      ]);
    } else {
      createNewOrder();
    }
  };

  // ===== TABLE RESERVATION =====
  const reserveTable = (tableNo) => {
    const cleanName = customerName.trim();
    if (!cleanName) return Alert.alert("Error", "Enter name");

    const minutes = parseInt(timeRequired);
    if (!minutes) return Alert.alert("Error", "Enter valid minutes");

    const start = new Date();
    const end = new Date(start.getTime() + minutes * 60000);

    const createReservation = () => {
      const obj = {
        id: Date.now().toString(),
        tableNo,
        customerName: cleanName,
        start,
        end,
        advance: 500,
      };
      setTables((p) => [...p, obj]);
      setTodayTables((p) => [...p, obj]);
      setTimeRequired("");
      setCustomerName("");
      Alert.alert("Table Reserved", `${cleanName}\nTable ${tableNo}\nAdvance Payment Please: Rs 500`);
    };

    const existing = tables.find((t) => t.customerName === cleanName);

    if (existing) {
      Alert.alert("Existing Reservation", `${cleanName} already reserved a table.`, [
        { text: "Update Reservation", onPress: createReservation },
        { text: "New Reservation", onPress: createReservation },
      ]);
    } else {
      createReservation();
    }
  };

  const remaining = (end) => {
    const d = Math.max(0, end - new Date());
    return `${Math.floor(d / 60000)}m ${Math.floor((d % 60000) / 1000)}s`;
  };

  // ===== SEARCH FUNCTIONS =====
  const searchMyOrders = () => {
    const cleanName = searchName.trim();
    if (!cleanName) {
      Alert.alert("Error", "Please enter your name");
      setSearchedOrders([]);
      setOrderSearchPerformed(false);
      return;
    }
    
    const results = orders.filter((o) => 
      o.name.toLowerCase() === cleanName.toLowerCase()
    );
    
    setSearchedOrders(results);
    setOrderSearchPerformed(true);
    
    if (results.length === 0) {
      Alert.alert("No Orders", `No orders found for "${cleanName}"`);
    }
  };

  const searchMyReservations = () => {
    const cleanName = searchName.trim();
    if (!cleanName) {
      Alert.alert("Error", "Please enter your name");
      setSearchedReservations([]);
      setReservationSearchPerformed(false);
      return;
    }
    
    const results = tables.filter((t) => 
      t.customerName.toLowerCase() === cleanName.toLowerCase()
    );
    
    setSearchedReservations(results);
    setReservationSearchPerformed(true);
    
    if (results.length === 0) {
      Alert.alert("No Reservations", `No reservations found for "${cleanName}"`);
    }
  };

  // ===== FEEDBACK =====
  const submitFeedback = () => {
    const r = parseInt(rating);
    if (!customerName || !rating) return Alert.alert("Error", "Enter name & rating");
    if (r < 1 || r > 5) return Alert.alert("Invalid Rating", "Rating must be between 1 and 5");

    const fb = { id: Date.now().toString(), name: customerName, rating: r, review };
    setFeedbacks((p) => [...p, fb]);
    setRating("");
    setReview("");
    setCustomerName("");
    Alert.alert("Thank you!", "Feedback submitted");
  };

  // ===== TABLE SCAN FUNCTIONS =====
  const startScan = () => {
    setScanning(true);
    setScreen("scan");
  };

  const getAvailableTables = () => {
    const allTables = [1, 2, 3, 4, 5, 6];
    return allTables.filter((n) => !tables.some((t) => t.tableNo === n));
  };

  const getReservedTables = () => {
    return tables;
  };

  // ===== LOGOUT =====
  const logout = () => {
    setUserRole(null);
    setScreen("login");
    setCart([]);
    setCustomerName("");
    setSearchName("");
    setSelectedOrder(null);
    setSearchedOrders([]);
    setSearchedReservations([]);
    setOrderSearchPerformed(false);
    setReservationSearchPerformed(false);
  };

  // ================= UI SCREENS =================

  // LOGIN
  if (screen === "login") {
    return (
      <View style={styles.center}>
        <Text style={styles.title}>Login / Signup</Text>
        <TextInput style={styles.input} placeholder="Email" placeholderTextColor="#94a3b8" onChangeText={setEmail} />
        <TextInput style={styles.input} placeholder="Password" placeholderTextColor="#94a3b8" secureTextEntry onChangeText={setPassword} />
        <TouchableOpacity style={styles.btn} onPress={loginHandler}>
          <Text style={styles.btnText}>Login</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // SPLASH
  if (screen === "splash") {
    return (
      <View style={styles.center}>
        <Image source={{ uri: mainLogo }} style={styles.logo} />
        <Text style={styles.title}>Spice With Hassan</Text>
      </View>
    );
  }

  // ROLE SELECTION SCREEN
  if (screen === "roleSelect") {
    return (
      <View style={styles.center}>
        <Image source={{ uri: mainLogo }} style={styles.logo} />
        <Text style={styles.title}>Welcome to Spice With Hassan</Text>
        <Text style={styles.subtitle}>Select your role</Text>

        <TouchableOpacity style={[styles.btn, styles.managerBtn]} onPress={() => selectRole("manager")}>
          <Image source={{ uri: managerIcon }} style={styles.roleIcon} />
          <Text style={styles.btnText}>Manager</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.btn, styles.customerBtn]} onPress={() => selectRole("customer")}>
          <Image source={{ uri: customerIcon }} style={styles.roleIcon} />
          <Text style={styles.btnText}>Customer</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // MANAGER PASSWORD SCREEN (WITH MOCK FACE ID)
  if (screen === "managerPassword") {
    // Show face scanning animation
    if (faceScanning) {
      return (
        <View style={styles.center}>
          <Image source={{ uri: faceIdIcon }} style={styles.faceIdLogo} />
          <Text style={styles.title}>Scanning Face...</Text>
          <Text style={styles.gray}>Please look at the camera</Text>
          <ActivityIndicator size="large" color="#facc15" style={{ marginTop: 20 }} />
          <Text style={[styles.gray, { marginTop: 20 }]}>This is a demo simulation</Text>
        </View>
      );
    }

    return (
      <View style={styles.center}>
        <Image source={{ uri: managerIcon }} style={styles.roleIconLarge} />
        <Text style={styles.title}>Manager Access</Text>
        <Text style={styles.subtitle}>Enter password or use Face ID</Text>
        
        <TextInput 
          style={styles.input} 
          placeholder="Password" 
          placeholderTextColor="#94a3b8" 
          secureTextEntry 
          value={managerPassword}
          onChangeText={setManagerPassword} 
        />
        
        <TouchableOpacity style={styles.btn} onPress={verifyManager}>
          <Text style={styles.btnText}>Verify Password</Text>
        </TouchableOpacity>

        {/* Mock Face ID Button (Works in Expo Go) */}
        <TouchableOpacity style={[styles.btn, styles.faceIdBtn]} onPress={mockFaceIdLogin}>
          <Image source={{ uri: faceIdIcon }} style={styles.faceIdIcon} />
          <Text style={styles.btnText}>Try Face ID (Demo)</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backBtn} onPress={() => setScreen("roleSelect")}>
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // MAIN MENU - WITH FEEDBACK ADDED TO CUSTOMER
  if (screen === "main") {
    return (
      <View style={styles.center}>
        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
          <Text style={styles.btnText}>Logout</Text>
        </TouchableOpacity>

        <Image source={{ uri: mainLogo }} style={styles.logo} />
        <Text style={styles.title}>Spice With Hassan</Text>
        <Text style={styles.roleText}>{userRole === "manager" ? "👔 Manager Mode" : "👤 Customer Mode"}</Text>

        {/* Customer Menu Options - WITH FEEDBACK */}
        {userRole === "customer" && (
          <>
            <TouchableOpacity style={styles.menuBtn} onPress={() => {
              setScreen("menu");
              setCustomerName("");
            }}>
              <Image source={{ uri: menuIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Menu</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => {
              setScreen("searchMyOrders");
              setSearchName("");
              setSearchedOrders([]);
              setOrderSearchPerformed(false);
            }}>
              <Image source={{ uri: orderIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>View Your Order</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => {
              setScreen("reserve");
              setCustomerName("");
            }}>
              <Image source={{ uri: reserveIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Reserve Table</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => {
              setScreen("searchMyReservations");
              setSearchName("");
              setSearchedReservations([]);
              setReservationSearchPerformed(false);
            }}>
              <Image source={{ uri: myReservationIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Your Reservation</Text>
            </TouchableOpacity>
            
            {/* FEEDBACK BUTTON FOR CUSTOMER */}
            <TouchableOpacity style={styles.menuBtn} onPress={() => {
              setScreen("feedback");
              setCustomerName("");
              setRating("");
              setReview("");
            }}>
              <Image source={{ uri: customerIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Feedback</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.menuBtn, styles.scanBtn]} onPress={startScan}>
              <Image source={{ uri: scanIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Table Scan</Text>
            </TouchableOpacity>
          </>
        )}

        {/* Manager Menu Options */}
        {userRole === "manager" && (
          <>
            <TouchableOpacity style={styles.menuBtn} onPress={() => setScreen("menu")}>
              <Image source={{ uri: menuIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Menu</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => setScreen("allOrders")}>
              <Image source={{ uri: orderIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>View Orders</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => setScreen("active")}>
              <Image source={{ uri: tableIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Active Tables</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => setScreen("today")}>
              <Image source={{ uri: myReservationIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Today Reservation</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuBtn} onPress={() => setScreen("viewFeedbacks")}>
              <Image source={{ uri: customerIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>View Feedbacks</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.menuBtn, styles.scanBtn]} onPress={startScan}>
              <Image source={{ uri: scanIcon }} style={styles.menuIcon} />
              <Text style={styles.btnText}>Table Scan</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    );
  }

  // SCANNING SCREEN
  if (screen === "scan") {
    return (
      <View style={styles.center}>
        <Image source={{ uri: scanIcon }} style={styles.scanningLogo} />
        <Text style={styles.title}>Scanning Tables...</Text>
        <Text style={styles.gray}>Please wait</Text>
      </View>
    );
  }

  // SCAN RESULT SCREEN
  if (screen === "scanResult") {
    return (
      <View style={styles.center}>
        <Text style={styles.title}>Table Status</Text>
        
        <TouchableOpacity 
          style={[styles.btn, styles.availableBtn]} 
          onPress={() => {
            const available = getAvailableTables();
            if (available.length === 0) {
              Alert.alert("No Tables", "No tables available at the moment");
            } else {
              setScreen("availableTables");
            }
          }}
        >
          <Text style={styles.btnText}>Tables Available ({getAvailableTables().length})</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.btn, styles.reservedBtn]} 
          onPress={() => {
            const reserved = getReservedTables();
            if (reserved.length === 0) {
              Alert.alert("No Reservations", "No tables are currently reserved");
            } else {
              setScreen("reservedTables");
            }
          }}
        >
          <Text style={styles.btnText}>Tables Reserved ({getReservedTables().length})</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back to Main</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // AVAILABLE TABLES SCREEN
  if (screen === "availableTables") {
    const availableTables = getAvailableTables();
    
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Available Tables</Text>
        
        {availableTables.length > 0 ? (
          availableTables.map((tableNo) => (
            <View key={tableNo} style={styles.card}>
              <Image source={{ uri: tableIcon }} style={styles.icon} />
              <View>
                <Text style={styles.whiteBold}>Table {tableNo}</Text>
                <Text style={styles.green}>✓ Available Now</Text>
              </View>
            </View>
          ))
        ) : (
          <Text style={styles.white}>No tables available at the moment</Text>
        )}

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("scanResult")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // RESERVED TABLES SCREEN
  if (screen === "reservedTables") {
    const reservedTables = getReservedTables();
    
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Reserved Tables</Text>
        
        {reservedTables.length > 0 ? (
          reservedTables.map((table) => (
            <View key={table.id} style={styles.cardCol}>
              <View style={styles.row}>
                <Image source={{ uri: tableIcon }} style={styles.smallIcon} />
                <Text style={styles.whiteBold}>Table {table.tableNo}</Text>
              </View>
              <Text style={styles.white}>Customer: {table.customerName}</Text>
              <Text style={styles.gray}>Start: {table.start.toLocaleTimeString()}</Text>
              <Text style={styles.gray}>End: {table.end.toLocaleTimeString()}</Text>
              <Text style={styles.total}>Time Left: {remaining(new Date(table.end))}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.white}>No tables are currently reserved</Text>
        )}

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("scanResult")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // MENU
  if (screen === "menu") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Menu</Text>
        <TextInput 
          style={styles.input} 
          placeholder="Your Name" 
          placeholderTextColor="#94a3b8" 
          value={customerName} 
          onChangeText={setCustomerName} 
        />

        {menuData.map((i) => (
          <TouchableOpacity key={i.id} style={styles.card} onPress={() => addToCart(i)}>
            <Image source={{ uri: i.icon }} style={styles.icon} />
            <Text style={styles.white}>{i.name} — Rs {i.price}</Text>
          </TouchableOpacity>
        ))}

        <Text style={styles.total}>Total: Rs {totalPayment}</Text>

        <TouchableOpacity style={styles.btn} onPress={placeOrder}>
          <Text style={styles.btnText}>Place Order</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // SEARCH MY ORDERS
  if (screen === "searchMyOrders") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>View Your Orders</Text>
        
        <TextInput 
          style={styles.input} 
          placeholder="Enter Your Name" 
          placeholderTextColor="#94a3b8" 
          value={searchName} 
          onChangeText={setSearchName} 
        />

        <TouchableOpacity style={styles.btn} onPress={searchMyOrders}>
          <Text style={styles.btnText}>Search Orders</Text>
        </TouchableOpacity>

        {orderSearchPerformed && (
          <>
            {searchedOrders.length > 0 ? (
              searchedOrders.map((o) => (
                <TouchableOpacity key={o.id} onPress={() => setSelectedOrder(o)}>
                  <View style={styles.cardCol}>
                    <Text style={styles.whiteBold}>{o.name}</Text>
                    {o.items.map((it, idx) => (
                      <Text key={idx} style={styles.gray}>• {it.name} — Rs {it.price}</Text>
                    ))}
                    <Text style={styles.total}>Total: Rs {o.total}</Text>

                    {selectedOrder?.id === o.id && (
                      <TouchableOpacity style={styles.payBtn} onPress={() => setScreen("payModal")}>
                        <Text style={styles.btnText}>Pay Now</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </TouchableOpacity>
              ))
            ) : (
              <Text style={styles.white}>No orders found for "{searchName}"</Text>
            )}
          </>
        )}

        <TouchableOpacity 
          style={styles.btn} 
          onPress={() => { 
            setScreen("main"); 
            setSelectedOrder(null); 
            setSearchName(""); 
            setSearchedOrders([]);
            setOrderSearchPerformed(false);
          }}
        >
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // ALL ORDERS (for manager)
  if (screen === "allOrders") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>All Orders</Text>

        {orders.length > 0 ? (
          orders.map((o) => (
            <TouchableOpacity key={o.id} onPress={() => setSelectedOrder(o)}>
              <View style={styles.cardCol}>
                <Text style={styles.whiteBold}>{o.name}</Text>
                {o.items.map((it, idx) => (
                  <Text key={idx} style={styles.gray}>• {it.name} — Rs {it.price}</Text>
                ))}
                <Text style={styles.total}>Total: Rs {o.total}</Text>

                {selectedOrder?.id === o.id && (
                  <TouchableOpacity style={styles.payBtn} onPress={() => setScreen("payModal")}>
                    <Text style={styles.btnText}>Pay Now</Text>
                  </TouchableOpacity>
                )}
              </View>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.white}>No orders have been placed yet</Text>
        )}

        <TouchableOpacity style={styles.btn} onPress={() => { setScreen("main"); setSelectedOrder(null); }}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // SEARCH MY RESERVATIONS
  if (screen === "searchMyReservations") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Your Reservations</Text>
        
        <TextInput 
          style={styles.input} 
          placeholder="Enter Your Name" 
          placeholderTextColor="#94a3b8" 
          value={searchName} 
          onChangeText={setSearchName} 
        />

        <TouchableOpacity style={styles.btn} onPress={searchMyReservations}>
          <Text style={styles.btnText}>Search Reservations</Text>
        </TouchableOpacity>

        {reservationSearchPerformed && (
          <>
            {searchedReservations.length > 0 ? (
              searchedReservations.map((table) => (
                <View key={table.id} style={styles.cardCol}>
                  <View style={styles.row}>
                    <Image source={{ uri: tableIcon }} style={styles.smallIcon} />
                    <Text style={styles.whiteBold}>Table {table.tableNo}</Text>
                  </View>
                  <Text style={styles.gray}>Start: {table.start.toLocaleTimeString()}</Text>
                  <Text style={styles.gray}>End: {table.end.toLocaleTimeString()}</Text>
                  <Text style={styles.total}>Time Left: {remaining(new Date(table.end))}</Text>
                  <Text style={styles.advance}>Advance Paid: Rs {table.advance}</Text>
                </View>
              ))
            ) : (
              <Text style={styles.white}>No reservations found for "{searchName}"</Text>
            )}
          </>
        )}

        <TouchableOpacity 
          style={styles.btn} 
          onPress={() => { 
            setScreen("main"); 
            setSearchName(""); 
            setSearchedReservations([]);
            setReservationSearchPerformed(false);
          }}
        >
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // FEEDBACK SCREEN (for customers)
  if (screen === "feedback") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Customer Feedback</Text>
        <TextInput 
          style={styles.input} 
          placeholder="Your Name" 
          placeholderTextColor="#94a3b8" 
          value={customerName} 
          onChangeText={setCustomerName} 
        />
        <TextInput 
          style={styles.input} 
          placeholder="Rating (1-5)" 
          placeholderTextColor="#94a3b8" 
          value={rating} 
          onChangeText={setRating} 
          keyboardType="numeric" 
        />
        <TextInput 
          style={styles.input} 
          placeholder="Write Review" 
          placeholderTextColor="#94a3b8" 
          value={review} 
          onChangeText={setReview} 
          multiline 
        />

        <TouchableOpacity style={styles.btn} onPress={submitFeedback}>
          <Text style={styles.btnText}>Submit Feedback</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // PAY MODAL
  if (screen === "payModal") {
    return (
      <View style={styles.center}>
        <Text style={styles.title}>Choose Payment Method</Text>

        <TouchableOpacity style={styles.payOption} onPress={() => Alert.alert("Easypaisa", "Proceed to Easypaisa payment")}>
          <Image source={{ uri: easypaisaLogo }} style={styles.payLogo} />
          <Text style={styles.whiteBold}>Easypaisa</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.payOption} onPress={() => Alert.alert("JazzCash", "Proceed to JazzCash payment")}>
          <Image source={{ uri: jazzCashLogo }} style={styles.payLogo} />
          <Text style={styles.whiteBold}>JazzCash</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.btn} 
          onPress={() => {
            if (userRole === "manager") {
              setScreen("allOrders");
            } else {
              setScreen("searchMyOrders");
            }
            setSelectedOrder(null);
          }}
        >
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

    // RESERVE TABLE
  if (screen === "reserve") {
    const all = [1, 2, 3, 4, 5, 6];
    const free = all.filter((n) => !tables.some((t) => t.tableNo === n));

    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Reserve Table</Text>
        <TextInput 
          style={styles.input} 
          placeholder="Your Name" 
          placeholderTextColor="#94a3b8" 
          value={customerName} 
          onChangeText={setCustomerName} 
        />
        <TextInput 
          style={styles.input} 
          placeholder="Minutes" 
          placeholderTextColor="#94a3b8" 
          value={timeRequired} 
          onChangeText={setTimeRequired} 
          keyboardType="numeric" 
        />

        {free.length > 0 ? (
          free.map((n) => (
            <TouchableOpacity key={n} style={styles.card} onPress={() => reserveTable(n)}>
              <Image source={{ uri: tableIcon }} style={styles.icon} />
              <Text style={styles.white}>Table {n}</Text>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.white}>No tables available for reservation</Text>
        )}

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // ACTIVE TABLES (MANAGER ONLY)
  if (screen === "active") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Active Tables</Text>
        {tables.length > 0 ? (
          tables.map((t) => (
            <View key={t.id} style={styles.cardCol}>
              <Text style={styles.white}>Table {t.tableNo} — {t.customerName}</Text>
              <Text style={styles.gray}>Start: {t.start.toLocaleTimeString()}</Text>
              <Text style={styles.gray}>End: {t.end.toLocaleTimeString()}</Text>
              <Text style={styles.total}>Remaining: {remaining(t.end)}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.white}>No active tables</Text>
        )}
        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // TODAY'S RESERVATION (MANAGER ONLY)
  if (screen === "today") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>Today's Reservations</Text>
        {todayTables.length > 0 ? (
          todayTables.map((t) => (
            <View key={t.id} style={styles.cardCol}>
              <Text style={styles.white}>Table {t.tableNo} — {t.customerName}</Text>
              <Text style={styles.gray}>Start: {t.start.toLocaleTimeString()}</Text>
              <Text style={styles.gray}>End: {t.end.toLocaleTimeString()}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.white}>No reservations today</Text>
        )}
        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // VIEW FEEDBACKS (MANAGER ONLY)
  if (screen === "viewFeedbacks") {
    return (
      <ScrollView style={styles.page}>
        <Text style={styles.title}>All Feedbacks</Text>

        {feedbacks.length > 0 ? (
          feedbacks.map((f) => (
            <View key={f.id} style={styles.cardCol}>
              <Text style={styles.whiteBold}>{f.name} — ⭐ {f.rating}/5</Text>
              <Text style={styles.gray}>{f.review}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.white}>No feedbacks yet</Text>
        )}

        <TouchableOpacity style={styles.btn} onPress={() => setScreen("main")}>
          <Text style={styles.btnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  return null;
}

// ===== COMPLETE STYLES =====

const styles = StyleSheet.create({
  center: {
    flex: 1,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  page: {
    flex: 1,
    backgroundColor: "#0f172a",
    padding: 20,
  },
  title: {
    fontSize: 26,
    color: "#facc15",
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 18,
    color: "#94a3b8",
    marginBottom: 30,
  },
  input: {
    backgroundColor: "#1e293b",
    color: "white",
    padding: 12,
    marginVertical: 8,
    borderRadius: 10,
    width: "100%",
  },
  btn: {
    backgroundColor: "#facc15",
    padding: 14,
    borderRadius: 12,
    marginTop: 10,
    width: 220,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 10,
  },
  btnText: {
    color: "#0f172a",
    fontWeight: "bold",
    fontSize: 16,
  },
  logoutBtn: {
    position: "absolute",
    top: 40,
    left: 20,
    backgroundColor: "#ef4444",
    padding: 10,
    borderRadius: 10,
    zIndex: 1,
  },
  backBtn: {
    marginTop: 15,
  },
  backText: {
    color: "#94a3b8",
    fontSize: 16,
  },
  card: {
    backgroundColor: "#1e293b",
    padding: 14,
    borderRadius: 12,
    marginVertical: 6,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  cardCol: {
    backgroundColor: "#1e293b",
    padding: 14,
    borderRadius: 12,
    marginVertical: 6,
  },
  icon: {
    width: 40,
    height: 40,
  },
  smallIcon: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  logo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
  },
  white: {
    color: "white",
  },
  whiteBold: {
    color: "white",
    fontWeight: "bold",
  },
  gray: {
    color: "#cbd5e1",
  },
  green: {
    color: "#4ade80",
    fontWeight: "bold",
  },
  total: {
    color: "#facc15",
    fontWeight: "bold",
    marginTop: 6,
  },
  advance: {
    color: "#facc15",
    marginTop: 4,
  },
  payBtn: {
    backgroundColor: "#facc15",
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
    alignItems: "center",
    width: 120,
  },
  payOption: {
    backgroundColor: "#1e293b",
    padding: 14,
    borderRadius: 12,
    marginVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    width: 250,
    justifyContent: "flex-start",
    gap: 15,
  },
  payLogo: {
    width: 40,
    height: 40,
    resizeMode: "contain",
  },
  // FACE ID STYLES
  faceIdBtn: {
    backgroundColor: "#10b981",
    marginTop: 10,
  },
  faceIdIcon: {
    width: 24,
    height: 24,
  },
  faceIdLogo: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  // ROLE SELECTION STYLES
  managerBtn: {
    backgroundColor: "#3b82f6",
    marginBottom: 15,
  },
  customerBtn: {
    backgroundColor: "#22c55e",
    marginBottom: 15,
  },
  roleIcon: {
    width: 24,
    height: 24,
  },
  roleIconLarge: {
    width: 80,
    height: 80,
    marginBottom: 20,
  },
  roleText: {
    color: "#94a3b8",
    fontSize: 16,
    marginBottom: 20,
  },
  // MENU BUTTON STYLES
  menuBtn: {
    backgroundColor: "#facc15",
    padding: 14,
    borderRadius: 12,
    marginTop: 10,
    width: 250,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 10,
  },
  menuIcon: {
    width: 24,
    height: 24,
  },
  // SCAN FEATURE STYLES
  scanBtn: {
    backgroundColor: "#3b82f6",
  },
  scanIcon: {
    width: 24,
    height: 24,
  },
  scanningLogo: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  availableBtn: {
    backgroundColor: "#22c55e",
    marginVertical: 10,
  },
  reservedBtn: {
    backgroundColor: "#ef4444",
    marginVertical: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
});